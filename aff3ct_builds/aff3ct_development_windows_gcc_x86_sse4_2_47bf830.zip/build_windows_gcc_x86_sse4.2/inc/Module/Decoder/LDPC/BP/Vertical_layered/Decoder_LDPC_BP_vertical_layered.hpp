#ifndef DECODER_LDPC_BP_VERTICAL_LAYERED_HPP_
#define DECODER_LDPC_BP_VERTICAL_LAYERED_HPP_

#include "Tools/Algo/Sparse_matrix/Sparse_matrix.hpp"
#include "Tools/Code/LDPC/Update_rule/SPA/Update_rule_SPA.hpp"

#include "../../../Decoder_SISO_SIHO.hpp"
#include "../Decoder_LDPC_BP.hpp"

namespace aff3ct
{
namespace module
{
template <typename B = int, typename R = float, class Update_rule = tools::Update_rule_SPA<R>>
class Decoder_LDPC_BP_vertical_layered : public Decoder_SISO_SIHO<B,R>, public Decoder_LDPC_BP
{
protected:
	const std::vector<uint32_t> &info_bits_pos;

	Update_rule up_rule;

	// data structures for iterative decoding
	std::vector<std::vector<R>> var_nodes;
	std::vector<std::vector<R>> messages;
	std::vector<R             > contributions;
	std::vector<uint32_t      > messages_offsets;

	bool init_flag; // reset the chk_to_var vector at the begining of the iterative decoding

public:
	Decoder_LDPC_BP_vertical_layered(const int K, const int N, const int n_ite,
	                                 const tools::Sparse_matrix &H,
	                                 const std::vector<unsigned> &info_bits_pos,
	                                 const Update_rule &up_rule,
	                                 const bool enable_syndrome = true,
	                                 const int syndrome_depth = 1,
	                                 const int n_frames = 1);
	virtual ~Decoder_LDPC_BP_vertical_layered();
	void reset();

protected:
	void _decode_siso   (const R *Y_N1, R *Y_N2, const int frame_id);
	void _decode_siho   (const R *Y_N,  B *V_K,  const int frame_id);
	void _decode_siho_cw(const R *Y_N,  B *V_N,  const int frame_id);

	void _load             (const R *Y_N, const int frame_id);
	void _decode           (const int frame_id);
	void _decode_single_ite(std::vector<R> &var_nodes, std::vector<R> &messages);
};
}
}

#include "Decoder_LDPC_BP_vertical_layered.hxx"

#endif /* DECODER_LDPC_BP_VERTICAL_LAYERED_HPP_ */
