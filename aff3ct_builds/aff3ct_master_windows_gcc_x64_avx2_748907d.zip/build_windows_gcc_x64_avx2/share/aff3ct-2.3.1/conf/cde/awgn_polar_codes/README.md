This folder contains a list of polar codes (best channels) used to determine the frozen bits.
Those polar codes has been generated with the density evolution method proposed by Tal & Vardy (TV).

The numbers in the sub-folders represent `m` = log2(`N`) with `N` the codeword size.