#ifndef ARGUMENT_TAG_HPP_
#define ARGUMENT_TAG_HPP_

#include <string>
#include <vector>

namespace aff3ct
{
namespace tools
{

using Argument_tag = std::vector<std::string>;

}
}

#endif /* ARGUMENT_TAG_HPP_ */
