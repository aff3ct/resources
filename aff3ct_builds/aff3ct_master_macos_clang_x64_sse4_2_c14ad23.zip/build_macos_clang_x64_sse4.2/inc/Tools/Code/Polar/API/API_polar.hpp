#ifndef API_POLAR_HPP_
#define API_POLAR_HPP_

namespace aff3ct
{
namespace tools
{
class API_polar {};
}
}

#endif /* API_POLAR_HPP_ */
